<?php

if(isset($_POST['submit'])){
  mysql_connect('localhost', 'neonscri_main', 'Imsa1135!')or die(mysql_error());
  mysql_select_db('neonscri_main')or die(mysql_error());

  $result = mysql_query('SELECT * FROM transactions WHERE tranID="'.mysql_real_escape_string($_POST['trans']).'" AND Active=0')or die(mysql_error());
  if(mysql_num_rows($result) == 1){
    if($_POST['password'] != $_POST['confirm']){
      $error = "Error! Password's don't match!";
    }
    if($_POST['username'] == "" || $_POST['password'] == "" || $_POST['confirm'] == "" || $_POST['trans'] == ""){
      $error = "Error! All fields required!";
    }
    $result = mysql_query('SELECT * FROM users WHERE Username="'.$_POST['username'].'"')or die(mysql_error());
    if(mysql_num_rows($result) > 0){
      $error = "Username already taken!";
    }

    if(!isset($error)){
      mysql_query('INSERT INTO users (`Username`, `Pass`, `Paid`, `OwnedScripts`) VALUES ("'.mysql_real_escape_string($_POST['username']).'", "'.md5(mysql_real_escape_string($_POST['confirm'])).'", "1", "1")')or die(mysql_error());
      mysql_query('UPDATE transactions SET Active=1 WHERE tranID="'.mysql_real_escape_string($_POST['trans']).'"')or die(mysql_error());
      $success = "Hooray! You're all set!";
    }
  }else{
    $error = "Error! Invalid Transaction ID!";
  }
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>NEONScripts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="navbar navbar-inverse">
      <div class="navbar-inner">
        <div class="container">
          <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="top-nav">
            <div class="logo">
              <a href="http://neonscripts.com"><img src="img/logo.png"></a>
            </div>
            <div class="loginForm pull-right">
              <form class="form-horizontal">
                <input class="loginInput" type="text" placeholder="Username">
                <input class="loginInput" type="password" placeholder="Password">
                <input class="loginButton" type="submit" value="Login">
              </form>
            </div>
          </div>
          <div class="nav-collapse collapse">
            <ul class="nav">
              <li><a href="index.html">Home</a></li>
              <li><a href="#">Script Market</a></li>
              <li><a href="register.html">Register</a></li>
              <li><a href="claim.php">Claim Pre Order</a></li>
              <li><a href="download.php?file=NEONCrabsPremium.zip">Download</a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div>
      </div>
    </div>
    <div class="main-body">
      <div class="break"></div>
      <div class="container">
        <?php if(isset($success)){?>
        <div class="span8 offset2 well">
          <h2><?php echo $success; ?></h2>
        </div>
        <?php }else{ ?>
        <?php if(isset($error)){ echo '<div class="alert alert-error">'.$error.'</div>'; } ?>
        <div class="span3 offset4 well">
          <h2>Claim Pre Order</h2>
          <form action="claim.php" method="POST">
            <label>Transaction ID</label>
            <input type="text" name="trans" class="span3">
            <label>Username</label>
            <input type="text" name="username" class="span3">
            <label>Password</label>
            <input type="password" name="password" class="span3">
            <label>Confirm</label>
            <input type="password" name="confirm" class="span3">
            <input type="submit" name="submit" value="Sign up" class="btn btn-primary pull-right">
          <div class="clearfix"></div>
          </form>
        </div>
        <?php } ?>
      </div> <!-- /container -->
    </div>
    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap-transition.js"></script>
    <script src="js/bootstrap-alert.js"></script>
    <script src="js/bootstrap-modal.js"></script>
    <script src="js/bootstrap-dropdown.js"></script>
    <script src="js/bootstrap-scrollspy.js"></script>
    <script src="js/bootstrap-tab.js"></script>
    <script src="js/bootstrap-tooltip.js"></script>
    <script src="js/bootstrap-popover.js"></script>
    <script src="js/bootstrap-button.js"></script>
    <script src="js/bootstrap-collapse.js"></script>
    <script src="js/bootstrap-carousel.js"></script>
    <script src="js/bootstrap-typeahead.js"></script>

  </body>
</html>