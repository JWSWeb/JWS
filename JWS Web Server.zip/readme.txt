***JWS Web Server*** V3.2

----------------------

1. Upload the JWS.ZIP folder to web server and unpack

claim.php

ApiController.class.php

2. Configure the server settings in config.txt and save

3. Open JWS_Web_Server.jar on controll PC and load config.txt

4. Click connect

Thats it! you are connected :)